---- NOTES ----

# Run/Import the 'mousemove.sql' file to create the database and table.

# Run 'input.php' in a browser which is running php server.

# Restore the first(current) window so that we can see the second window.

# Click on the 'Open Second Window' to create the 'output' window.

# 'Play Live' will enable live mousemove capture in both windows

# 'Record' will record the mousemove and 'Play' will enable the last recorded moves in both browsers

# Incase if the php files are not working then there is an 'input.html' in the '/HTML' folder which will show mouse capture and realtime recording in one window.


--- Thanks ---
Sabin Chacko
sabinonweb@gmail.com